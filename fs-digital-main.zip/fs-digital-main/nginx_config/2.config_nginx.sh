#!/bin/bash

echo `date` "[INFO] nginx configuration: SPRING_CONFIG_URL: ${SPRING_CONFIG_URL}."
echo `date` "[INFO] nginx configuration: SPRING_CONFIG_ENVIRONMENT: ${SPRING_CONFIG_ENVIRONMENT}."
echo `date` "[INFO] nginx configuration: SPRING_CONFIG_PROFILE: ${SPRING_CONFIG_PROFILE}."
echo `date` "[INFO] nginx configuration: SPRING_CONFIG_LABEL: ${SPRING_CONFIG_LABEL}."
echo `date` "[INFO] nginx configuration: APP_NAME: ${APP_NAME}."

# read list of file to be copy to the pod
HTTP_STATUS=$(curl -s -o /usr/share/nginx/html/fs-digital-main/assets/application.properties -w "%{http_code}" ${SPRING_CONFIG_URL}/${SPRING_CONFIG_ENVIRONMENT}/${SPRING_CONFIG_PROFILE}/${SPRING_CONFIG_LABEL}/application.properties)

if [ "${HTTP_STATUS}" != "200" ]; then
    echo `date` "[WARNING] nginx Config-service id not reachable local config will be used. error_code: ${HTTP_STATUS}."
fi

# Use default nginx configuration 
if [ ! -f /etc/nginx/nginx.conf ]; then
    echo `date` "[INFO] nginx configuration: using default nginx.conf."
    mv /etc/nginx/template_nginx.conf /etc/nginx/nginx.conf
fi

