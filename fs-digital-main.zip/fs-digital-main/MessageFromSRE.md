```
          _____                    _____                    _____                            _____                    _____          
         /\    \                  /\    \                  /\    \                          /\    \                  /\    \         
        /::\    \                /::\    \                /::\    \                        /::\____\                /::\____\        
       /::::\    \              /::::\    \              /::::\    \                      /:::/    /               /:::/    /        
      /::::::\    \            /::::::\    \            /::::::\    \                    /:::/    /               /:::/    /         
     /:::/\:::\    \          /:::/\:::\    \          /:::/\:::\    \                  /:::/    /               /:::/    /          
    /:::/__\:::\    \        /:::/__\:::\    \        /:::/__\:::\    \                /:::/    /               /:::/____/           
    \:::\   \:::\    \      /::::\   \:::\    \      /::::\   \:::\    \              /:::/    /               /::::\    \           
  ___\:::\   \:::\    \    /::::::\   \:::\    \    /::::::\   \:::\    \            /:::/    /      _____    /::::::\____\________  
 /\   \:::\   \:::\    \  /:::/\:::\   \:::\____\  /:::/\:::\   \:::\    \          /:::/____/      /\    \  /:::/\:::::::::::\    \ 
/::\   \:::\   \:::\____\/:::/  \:::\   \:::|    |/:::/__\:::\   \:::\____\        |:::|    /      /::\____\/:::/  |:::::::::::\____\
\:::\   \:::\   \::/    /\::/   |::::\  /:::|____|\:::\   \:::\   \::/    /        |:::|____\     /:::/    /\::/   |::|~~~|~~~~~     
 \:::\   \:::\   \/____/  \/____|:::::\/:::/    /  \:::\   \:::\   \/____/          \:::\    \   /:::/    /  \/____|::|   |          
  \:::\   \:::\    \            |:::::::::/    /    \:::\   \:::\    \               \:::\    \ /:::/    /         |::|   |          
   \:::\   \:::\____\           |::|\::::/    /      \:::\   \:::\____\               \:::\    /:::/    /          |::|   |          
    \:::\  /:::/    /           |::| \::/____/        \:::\   \::/    /                \:::\__/:::/    /           |::|   |          
     \:::\/:::/    /            |::|  ~|               \:::\   \/____/                  \::::::::/    /            |::|   |          
      \::::::/    /             |::|   |                \:::\    \                       \::::::/    /             |::|   |          
       \::::/    /              \::|   |                 \:::\____\                       \::::/    /              \::|   |          
        \::/    /                \:|   |                  \::/    /                        \::/____/                \:|   |          
         \/____/                  \|___|                   \/____/                          ~~                       \|___|          
                                                                                                                                     
```




This GitLab project was created as part of the pipeline automation.
https://confluence.almuk.santanderuk.corp/x/wGgnAw

It is a simple helloworld application in the chosen technology (`/src`).
It also has build files (`Dockerfile`, `pom.xml`, `package.json`, etc), and Pipeline files (`Jenkinsfile`). 


Reference Project
-----------------
This GitLab project is based on the `Reference projects`.
https://uk-gitlab.almuk.santanderuk.corp/cicd-pipeline-uk-reference/helloworld-angularjs10-npm-server

The `Reference projects` have been created as documentation. They try to be the standard way to run pipelines.
The code is is in gitlab. The Pipeline files are in gitlab. 
They are completed with a PaaS project: `cicd-pipeline-uk-reference`.
The OpenShift namespace has a Jenkins instance in DEV with jobs to deploy all the HelloWorld applications.
There are also PRE and PRO jobs in cd-jenkins, in the `cicd-pipeline-uk-reference` folder.

DEV Environment
https://api-ukdev01a.paas.santanderuk.dev.corp/console/project/cicd-pipeline-uk-reference-dev/overview

PRE Environments
https://api-ukpre03a.paas.santanderuk.pre.corp/console/project/cicd-pipeline-uk-reference-pre/overview
https://api-ukpre04a.paas.santanderuk.pre.corp/console/project/cicd-pipeline-uk-reference-pre/overview

PRO Environments
https://api-ukpro05a.paas.santanderuk.corp/console/project/cicd-pipeline-uk-reference-pro/overview
https://api-ukpro05a.paas.santanderuk.corp/console/project/cicd-pipeline-uk-reference-pro/overview

How to proceed
--------------
1. Push your own code to the develop branch, overwriting Helloworld's code (`/src`). 
    This push should run the multibranch pipeline, deploying a container, as a snapshot, to your PaaS DEV project.
2. Adjust resource configuration (requests/limits) and liveness/readiness in the Jenkinsfiles.
    This push should run the multibranch pipeline, deploying the new application, as a snapshot, to your PaaS DEV project.
3. If your application is ready to use configuration, make sure you push it to the master branch of your GitLab configuration repository.
4. Modify your code to use configuration. Continue improving your application.
5. If you are ready to generate a relase, perform the following steps:
    1. Adjust in your PRE jenkinsfile the resource configuration (requests/limits) and the liveness/readiness. Adjust your route definition too.
    2. As an opseng, merge your application's configuration in dev to the confmgmnt develop branch in GitLab configuration repository.
    3. As an opseng, complete your configuration with PRE and PRO configuration. Merge it to the master branch of the confmgmnt repository.
    4. Merge your source code to master branch.
6. Run the release job from your DEV Jenkins.
    This job generates a software release. It tags your project with the version and merges back to develop. It will also update `pom.xml`/`package.json` with version.
    2 multibranch pipelines should run: a develop build first, and then one for the release.  
    The release job will run the tag-release job in cd-jenkins. The tag-release job will link softare and configuration, using a release tag (`R`).  
    The tag-release job will run the deploy-to-test job from cd-jenkins PRE. The deploy-to-test job deploysthe app to PRE.
7. **Important:** Please keep the project pipelines aligned to reference project for smooth integration and deployment. 




Related documentation
---------------------
* [Requests and Limits](https://confluence.almuk.santanderuk.corp/display/PAASBESTPR/Requests+and+Limits+for+your+Pod)
* [Liveness and readiness](https://confluence.almuk.santanderuk.corp/display/PAASBESTPR/Liveness+and+readiness+for+config-service)
* [Troubleshooting config-service](https://confluence.almuk.santanderuk.corp/display/PAASBESTPR/How+to+get+configuration+from+config-service+--+manually)


Main documentation
------------------
* [PaaS Best Practices](https://confluence.almuk.santanderuk.corp/display/PAASBESTPR/PaaS+Best+Practices+Home)
  First source of information for Projects on anything related to PaaS.
* [Pipeline Automation](https://confluence.almuk.santanderuk.corp/display/PIPELAUTO/Pipeline+Automation+Home)
  How to create pipelines with automation. How to use other automations.
* [Pipeline UK](https://confluence.almuk.santanderuk.corp/display/CHome/Pipeline+UK+Home)
  (Slightly out of date). How we do pipelines. How to create pipelines manually.
* [Upgrade DEV Jenkins](https://confluence.almuk.santanderuk.corp/display/PIPELAUTO/Upgrade+Jenkins+DEV+instance)
* [Upgrade/Redeploy config-service](https://confluence.almuk.santanderuk.corp/display/PIPELAUTO/Upgrade+or+Redeploy+config-service)
