import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrearsBannerComponent } from './arrears-banner.component';

describe('ArrearsBannerComponent', () => {
  let component: ArrearsBannerComponent;
  let fixture: ComponentFixture<ArrearsBannerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArrearsBannerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrearsBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
