import { Component } from '@angular/core';

@Component({
  selector: 'fs-arrears-banner',
  templateUrl: './arrears-banner.component.html',
  styleUrls: ['./arrears-banner.component.scss']
})
export class ArrearsBannerComponent { }
