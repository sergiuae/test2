import { Component } from '@angular/core';

@Component({
  selector: 'fs-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent {

  firstPanelOpenState = false;
  secondPanelOpenState = false;
  thirdPanelOpenState = false;
  test = "https://www.santander.co.uk/personal/support/help-with-managing-my-money/independent-help-support";

}
