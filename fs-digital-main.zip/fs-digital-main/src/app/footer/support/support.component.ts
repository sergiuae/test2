import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'fs-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.scss']
})
export class SupportComponent {

  constructor(private router: Router) { }

  openCallUsPage(): void {
    this.router.navigate(['call-us'])
  }

}
