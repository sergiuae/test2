import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'fs-card-helper',
  templateUrl: './card-helper.component.html',
  styleUrls: ['./card-helper.component.scss']
})
export class CardHelperComponent implements OnInit {
  @Input() data: any;
  @Input() idx: number = 0;

  reverse: boolean = false;

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.reverse = this.idx % 2 === 1;
  }

  goToUrl(url: string): void {
    this.router.navigate(["/"]).then(() => {
      window.location.href = url;
    });
  }
}
