import { Component } from '@angular/core';

@Component({
  selector: 'fs-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  banners = [
    {
      title: 'Pay or Manage your Overdue amounts',
      linkText: 'Visit our website',
      url: 'https://www.santander.co.uk/personal/support/help-with-managing-my-money/overdue-payment',
      ilustration: 'assets/svg/fs-pay-manage.svg'
    },
    {
      title: 'Budget Planner - <br>helping plan finances',
      linkText: 'Go to Budget Planner',
      url: 'https://www.santander.co.uk/personal/support/if-finances-are-a-struggle/budget-planning',
      ilustration: 'assets/svg/fs-bp.svg'
    },
    {
      title: 'Financial Support- we\'re here to help',
      linkText: 'Visit out website',
      url: 'https://www.santander.co.uk/personal/support/if-finances-are-a-struggle',
      ilustration: 'assets/svg/fs-fin-support.svg'
    }
  ]
}
