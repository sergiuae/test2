import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ArrearsBannerComponent } from './home/arrears-banner/arrears-banner.component';
import { CardHelperComponent } from './home/card-helper/card-helper.component';
import { FaqComponent } from './footer/faq/faq.component';
import { SupportComponent } from './footer/support/support.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDividerModule } from '@angular/material/divider';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { CallUsComponent } from './call-us/call-us.component';
import { PhoneNumberComponent } from './call-us/phone-number/phone-number.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ArrearsBannerComponent,
    CardHelperComponent,
    FaqComponent,
    SupportComponent,
    CallUsComponent,
    PhoneNumberComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatDividerModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
