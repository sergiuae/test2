import { Component } from '@angular/core';

@Component({
  selector: 'fs-call-us',
  templateUrl: './call-us.component.html',
  styleUrls: ['./call-us.component.scss']
})
export class CallUsComponent {
  departments = [
    {
      department: 'Mortgages',
      number: '0700000000',
      schedule: {
        weekDays: {
          open: 8,
          close: 6
        },
        weekends: {
          open: 9,
          close: 5
        }
      }
    },
    {
      department: 'Loans',
      number: '0700000001',
      schedule: {
        weekDays: {
          open: 8,
          close: 6
        },
        weekends: {
          open: 9,
          close: 5
        }
      }
    },
    {
      department: 'Credit Cards',
      number: '0700000002',
      schedule: {
        weekDays: {
          open: 8,
          close: 6
        },
        weekends: {
          open: 9,
          close: 5
        }
      }
    },
    {
      department: 'Current Accounts',
      number: '0700000003',
      schedule: {
        weekDays: {
          open: 8,
          close: 6
        },
        weekends: {
          open: 9,
          close: 5
        }
      }
    }
  ]
}
