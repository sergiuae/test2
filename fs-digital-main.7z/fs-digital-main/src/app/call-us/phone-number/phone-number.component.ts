import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'fs-phone-number',
  templateUrl: './phone-number.component.html',
  styleUrls: ['./phone-number.component.scss']
})
export class PhoneNumberComponent implements OnInit, OnDestroy {
  @Input() phone: any;

  green: string = 'assets/svg/fs-ico-call_us-green.svg';
  red: string = 'assets/svg/fs-ico-call_us-red.svg';
  image: string = '';

  intervalSubs: Subscription = new Subscription;

  wdOpen: number = 0;
  wdClose: number = 0;
  weOpen: number = 0;
  weClose: number = 0;

  ngOnInit(): void {
    this.wdOpen = this.phone?.schedule?.weekDays?.open;
    this.wdClose = this.phone?.schedule?.weekDays?.close;
    this.weOpen = this.phone?.schedule?.weekends?.open;
    this.weClose = this.phone?.schedule?.weekends?.close;

    this.checkWorkingHours();
    this.intervalSubs = interval(60000).subscribe(v => {
      this.checkWorkingHours();
    })
  }


  ngOnDestroy(): void {
    if (this.intervalSubs) {
      this.intervalSubs.unsubscribe()
    }
  }

  private checkWorkingHours(): void {
    const weekDays = [1, 2, 3, 4, 5];
    const weekends = [6];

    const currentDate = new Date();
    const currentDay = currentDate.getDay();
    const currentHour = currentDate.getUTCHours();

    if (!currentDay) {
      this.image = this.red;
      return;
    }

    if (weekDays.includes(currentDay)) {
      if (currentHour >= this.wdOpen && currentHour < this.wdClose + 12) {
        this.image = this.green;
      } else {
        this.image = this.red;
      }
      return;
    }

    if (weekends.includes(currentDay)) {
      if (currentHour >= this.weOpen && currentHour < this.weClose + 12) {
        this.image = this.green;
      } else {
        this.image = this.red;
      }
    }
  }
}
