Changelog.md
============

0.0.0  
* Inital version created with pipeline automation from reference project
  https://uk-gitlab.almuk.santanderuk.corp/cicd-pipeline-uk-reference/helloworld-angularjs12-npm-server
  SRE@santander.co.uk